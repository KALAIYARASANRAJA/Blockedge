import axios from 'axios';
const SERVER_URL = 'http://localhost:9090/blockedge/api/v1/';

export async function getPersonsData(params){
    let response = await axios.get(SERVER_URL+'persons',{params});
    return response.data;
}