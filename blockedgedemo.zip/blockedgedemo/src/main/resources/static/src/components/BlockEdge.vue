<template>
  <div class="hello">
    <div class="head">
      <div class="filter">
        <select name="filter" class="mR10" v-model="filter">
          <option value="name">Name</option>
          <option value="phone">Phone</option>
          <option value="address">Address</option>
          <option value="salary">Salary</option>
          <option value="pension">Pension</option>
        </select>
        <input type="text" placeholder="Filter" v-model="filterVal">
      </div>
      <div class="search">
        <input type="text" class="mR10" placeholder="Search" v-model="search">
        <input type="button" value="submit" @click="changeList">
      </div>
    </div>

    <table>
    <tbody>
      <template v-if="!isLoading">
        <tr>
          <th>NAME</th>
          <th>PHONE</th>
          <th>ADDRESS</th>
          <th>SALARY</th>
          <th>PENSION</th>
        </tr>
        <tr v-for="person in listData" :key="person.name">
          <td>{{person.name}}</td>
          <td>{{person.phone}}</td>
          <td>{{person.address}}</td>
          <td>{{person.salary}}</td>
          <td>{{person.pension}}</td>
        </tr>
      </template>
      <div v-else>loading...</div>
    </tbody>
    </table>
  </div>
</template>

<script>
import {getPersonsData} from './../actions/BlockEdgeActions.js';

export default {
  name: 'BlockEdge',
  data(){
    return {
      listData : [],
      isLoading : true,
      filter : 'name',
      filterVal : '',
      search : ''
    }
  },
  beforeMount(){
    this.getList({});
  },

  methods : {
    changeList(){
      if(this.search.length > 2){
        this.getList({search : this.search});
      }
      else if(this.filter && this.filterVal.length>2){
        let param = {};
        param[this.filter] = this.filterVal;
        this.getList(param);
      }else{
         this.getList({});
      }
    },
    getList(params){
      this.isLoading = true;
      getPersonsData(params)
      .then((data)=>{
        this.listData = data;
      })
      .finally(()=>{
        this.isLoading = false;
      })
    }
  },

  watch : {
    filter(){
      this.search = '';
    },
    filterVal(){
      this.search = '';
    },
    search(){
      this.filter = '';
      this.filterVal = '';
    }
  }
}
</script>
<style scoped>
.head{
  display: flex;
  margin-bottom: 20px;
}
.mR10{
margin-right: 10px;
}
.filter{
  flex-grow: 1;
  text-align: left;
}
.filter, .search{
  display: inline-block;
}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #888888;
  text-align: left;
  padding: 8px;
}

tr {
  background-color: #dddddd;
}
</style>
