package com.blockedge.demo.blockedgedemo.common.util;

public enum RequestDataType {
	TEXT,
	NUMBER
}
