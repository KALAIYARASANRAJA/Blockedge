package com.blockedge.demo.blockedgedemo.common.util;

import java.io.File;
import java.io.InputStream;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.springframework.web.multipart.MultipartFile;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.blockedge.demo.blockedgedemo.common.exceptions.RestAPIException;
import com.blockedge.demo.blockedgedemo.common.exceptions.RestAPIException.Type;
import com.blockedge.demo.blockedgedemo.model.Person;

public class XmlToDomUtil {
	
	
	public static List<Person> getPersonDataFromxml(MultipartFile geodata,MultipartFile salarydata)
	{	
		
		List<Person> persons=new ArrayList<>();
		try
		{
			DocumentBuilderFactory   factory = DocumentBuilderFactory.newInstance();
			InputStream geoin=geodata.getInputStream();
			InputStream salaryin=salarydata.getInputStream();
			Document geodoc = factory.newDocumentBuilder().parse(geoin);
			Document salarydoc = factory.newDocumentBuilder().parse(salaryin);
			Element geoelement=geodoc.getDocumentElement();
			Element salaryelement=salarydoc.getDocumentElement();
			NodeList geolist=geoelement.getElementsByTagName("person");
			NodeList salarylist=salaryelement.getElementsByTagName("person");
			if (geolist.getLength()<1 || salarylist.getLength()<1)
			{	
				System.out.println("Returning as xml has no mandatory values");
				throw new RestAPIException(Type.MANDATORY_PARAMS_NOT_FOUND);
			}
			for (int i=0;i<geolist.getLength();i++)
			{	
				Element subelement=(Element) geolist.item(i);
				String name=subelement.getAttribute("name");
				if (name==null)
				{
					System.out.println("Name isn't available for person "+ name);
					continue;
				}
				System.out.println("text content "+ geoelement.getElementsByTagName("address").item(i).getTextContent());
				String address= geoelement.getElementsByTagName("address").item(i).getTextContent();
				String phone= geoelement.getElementsByTagName("phonenumber").item(i).getTextContent();
				for (int j=0;i<salarylist.getLength();j++)
				{
					Element salarysubelement=(Element) salarylist.item(j);
					if (name.equals(salarysubelement.getAttribute("name")))
					{
						String salary= salaryelement.getElementsByTagName("salary").item(j).getTextContent();
						String pension= salaryelement.getElementsByTagName("pension").item(j).getTextContent();
						
						ValidationUtil.validateRequest("address",address, null, null);
						ValidationUtil.validateRequest("phone",phone, 12, RequestDataType.NUMBER);
						
						if (salary!=null &&  pension!=null)
						{	
							if (Person.CURRENCY_SYMBOL_MAP.containsKey(salary.toCharArray()[0]) || Person.CURRENCY_SYMBOL_MAP.containsKey(pension.toCharArray()[0]))
							{
								throw new RestAPIException(Type.INVALID_REQUESTDATA,null,"Missed curreny of pay");
							}
							
							BigDecimal salaryInfo=null;
							BigDecimal pensionInfo=null;
							try
							{	
								salaryInfo=new BigDecimal(salary.substring(1)).setScale(3);
							}
							catch(Exception ex)
							{
								System.out.println("salary content "+ salary);
								throw new RestAPIException(Type.INVALID_REQUESTDATA,"salary");
							}
							try
							{
								pensionInfo=new BigDecimal(pension.substring(1)).setScale(3);
							}
							catch(Exception ex)
							{
								System.out.println("pension content "+ pensionInfo);
								throw new RestAPIException(Type.INVALID_REQUESTDATA,"pension");
							}
							Person person=new Person(name, address, phone, salaryInfo, pensionInfo,Person.CURRENCY_SYMBOL_MAP.get(salary.toCharArray()[0]));
							System.out.println("Sucesfully formed person object "+ person.toString());
							persons.add(person);	
							break;
						}
						else
						{
							System.out.println("All data needed for adding a person not available "+ name);
							break;
						}		
					}
				}
			}
			//write to new XML
			writetoNewXml(persons,factory);
			return persons;	

		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	private static void writetoNewXml(List<Person> persons,DocumentBuilderFactory factory)
	{
		try
		{
			DocumentBuilder dBuilder = factory.newDocumentBuilder();
	        Document doc = dBuilder.newDocument();
	        
	        Element rootElement = doc.createElement("persondata");
            doc.appendChild(rootElement);
            
            for (Person person : persons)
            {
                rootElement.appendChild(createPersonElement(doc,person.getName(),person.getAddress(),person.getPhone(),person.getSalary(),person.getPension()));
            }
            
            // for output to file, console
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            // for pretty print
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            
            DOMSource source = new DOMSource(doc);
            StreamResult file = new StreamResult(new File("C:\\Users\\KALAIYARASAN\\Documents\\blockedge\\persons_"+System.currentTimeMillis()+".xml"));
            transformer.transform(source, file);


		}
		catch(Exception ex)
		{
			ex.printStackTrace();
		}
	}
	

    private static Node createPersonElement(Document doc, String name, String address, String phone, BigDecimal salary,BigDecimal pension) {
        Element person = doc.createElement("person");

        // set id attribute
        person.setAttribute("id", name);

        // create firstName element
        person.appendChild(createPersonElements(doc, person, "address", address));
        person.appendChild(createPersonElements(doc, person, "phonenumber", phone));
        person.appendChild(createPersonElements(doc, person, "salary", "$"+salary));
        person.appendChild(createPersonElements(doc, person, "pension", "$"+pension));
        return person;
    }
    
 // utility method to create text node
    private static Node createPersonElements(Document doc, Element element, String name, String value) {
        Element node = doc.createElement(name);
        node.appendChild(doc.createTextNode(value));
        return node;
    }
}
