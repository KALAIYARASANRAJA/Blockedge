package com.blockedge.demo.blockedgedemo.repository;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.blockedge.demo.blockedgedemo.dao.model.PersonDAO;


public interface PersonRepository  extends JpaRepository<PersonDAO,String>{
	
	
	public List<PersonDAO> findByName(String name);
	
	public List<PersonDAO> findByAddressContains(String address);
	
	public List<PersonDAO> findByAddress(String address);

	public List<PersonDAO> findByPhone(String phone);
	
	public List<PersonDAO> findBySalary(BigDecimal salary);
	
	public List<PersonDAO> findByPension(BigDecimal pension);



}
