package com.blockedge.demo.blockedgedemo.common.exceptions;

import java.util.Hashtable;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.context.request.WebRequest;

@ControllerAdvice
public class APIExceptionHandler {
	
	@ExceptionHandler(RestAPIException.class)
    public final ResponseEntity<Object> handleRestExceptions(RestAPIException ex, WebRequest request) {
		if (ex.getErrorCode()==HttpStatus.NO_CONTENT.value())
		{
			return new ResponseEntity(HttpStatus.NO_CONTENT);
		}
		else
		{
			return new ResponseEntity(ex.wrap(), HttpStatus.BAD_REQUEST);
		}
    }
	
	@ExceptionHandler(Exception.class)
    public final ResponseEntity<Object> handleAllExceptions(Exception ex, WebRequest request) {
		Map<String,Object> errorRes=new Hashtable<>();
    	errorRes.put("code",  HttpStatus.INTERNAL_SERVER_ERROR.value());
    	errorRes.put("message","Unforeseen Exception");
        return new ResponseEntity(errorRes, HttpStatus.INTERNAL_SERVER_ERROR);
    }

}
