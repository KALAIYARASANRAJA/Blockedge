package com.blockedge.demo.blockedgedemo.common.util;

import org.apache.commons.lang3.StringUtils;

import com.blockedge.demo.blockedgedemo.common.exceptions.RestAPIException;
import com.blockedge.demo.blockedgedemo.common.exceptions.RestAPIException.Type;

public class ValidationUtil {
	
	public static void validateRequest(String paramKey,String param,Integer maxLent,RequestDataType datatype)
	{
		if (param==null)
		{
			throw new RestAPIException(Type.MANDATORY_PARAMS_NOT_FOUND,paramKey);
		}
		
		if (maxLent!=null && param.length()>maxLent)
		{
			throw new RestAPIException(Type.INVALID_REQUESTDATA,paramKey);
		}
		
		if (datatype == RequestDataType.NUMBER)
		{
			if (!StringUtils.isNumeric(param))
			{
				throw new RestAPIException(Type.INVALID_REQUESTDATA,paramKey);
			}
		}
	}

}
