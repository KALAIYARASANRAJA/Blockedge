package com.blockedge.demo.blockedgedemo.controller;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.blockedge.demo.blockedgedemo.common.exceptions.RestAPIException;
import com.blockedge.demo.blockedgedemo.common.exceptions.RestAPIException.Type;
import com.blockedge.demo.blockedgedemo.common.util.XmlToDomUtil;
import com.blockedge.demo.blockedgedemo.model.Person;
import com.blockedge.demo.blockedgedemo.service.PersonService;

@RestController
public class ImportsController {
	
	public static final ArrayList<String> ALLOWED_CONTENT_TYPE=new ArrayList(Arrays.asList(new String[]{"application/xml"}));
	
	@Autowired
	private PersonService personService;
	
	@RequestMapping(value="/api/v1/import/person", method=RequestMethod.POST,consumes=MediaType.MULTIPART_FORM_DATA_VALUE)
	public Object imPortPersonData(
			@RequestParam("geodata") MultipartFile geofile,
			@RequestParam("salarydata") MultipartFile salaryfile,HttpServletRequest request)
	{	
		if (request.getRequestURI().contains("person"))
		{
			if (!ALLOWED_CONTENT_TYPE.contains(geofile.getContentType()) || !ALLOWED_CONTENT_TYPE.contains(salaryfile.getContentType()))
			{
				throw new RestAPIException(Type.INVALID_REQUESTDATA,null,"Invalid file input");
			}
			List<Person> persons=XmlToDomUtil.getPersonDataFromxml(geofile, salaryfile);
			personService.importPersons(persons);
		}
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}
}

