package com.blockedge.demo.blockedgedemo.model;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Hashtable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

public class Person {
	
	@JsonIgnore
	public static final HashMap<String, String> CURRENCY_SYMBOL_MAP=new HashMap<>();
	
	static {
		CURRENCY_SYMBOL_MAP.put("₹", "INR");
		CURRENCY_SYMBOL_MAP.put("$", "USD");
	}
	
	@JsonProperty("name")
	private String name;
	
	@JsonProperty("address")
	private String address;
	
	@JsonProperty("phone")
	private String phone;
	
	@JsonProperty("salary")
	private BigDecimal salary;
	
	@JsonProperty("pension")
	private BigDecimal pension;
	
	@JsonProperty("pay_currency")
	private String payCurrency;
	
	public Person(String name, String address, String phone, BigDecimal salary, BigDecimal pension,String payCurrency) {
		super();
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.salary = salary;
		this.pension = pension;
		this.payCurrency = payCurrency;
	}
	
	
	public String getName() {
		return name;
	}
	public String getAddress() {
		return address;
	}
	public String getPhone() {
		return phone;
	}
	public BigDecimal getSalary() {
		return salary;
	}
	public BigDecimal getPension() {
		return pension;
	}
	public String getPayCurrency() {
		return payCurrency;
	}
	
	@JsonIgnore
	public Hashtable<String, Object> getRawHash()
	{	
		Hashtable<String,Object> personHash=new Hashtable<>();
		personHash.put("name", getName());
		personHash.put("address", getAddress());
		personHash.put("phone", getPhone());
		personHash.put("salary", getSalary());
		personHash.put("pension", getPension());
		personHash.put("pay_currency", getPayCurrency());
		return personHash;
		
	}
	
	
	
	

}
