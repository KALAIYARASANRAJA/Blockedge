
package com.blockedge.demo.blockedgedemo.common.exceptions;

import java.util.Hashtable;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

public class RestAPIException extends RuntimeException {
	
	private Integer errorCode;
	private String errorMessage;
	private String fields;
	
	public Integer getErrorCode() {
		return errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public RestAPIException() {
	        super();
	    }
	    public RestAPIException(Integer errorCode,String message, Throwable cause) {
	        super(message, cause);
	    	this.errorCode=errorCode;
	    	this.errorMessage=message;
	    }
	    
	    public RestAPIException(Type type,String field) {
	        super(type.message);
	    	this.errorCode=type.code;
	    	this.errorMessage=type.message;
	    	this.fields=field;
	    }
	    
	    public RestAPIException(Type type,String field,String message) {
	        super(type.message);
	    	this.errorCode=type.code;
	    	this.errorMessage=message;
	    	this.fields=field;
	    }
	    
	    public RestAPIException(Type type) {
	        super(type.message);
	    	this.errorCode=type.code;
	    	this.errorMessage=type.message;
	    }
	    
	    public RestAPIException(String message) {
	        super(message);
	    }
	    
	    
	    
	    public enum Type
	    {	
	    	// params not found
	    	RESOURCE_NOT_FOUND_CRITERIA(204,"Resource Not Found for criteria"),

	    	
	    	// params not found
	    	MANDATORY_PARAMS_NOT_FOUND(1000,"Mandatory params not found"),
	    	INVALID_REQUESTDATA(1001,"Invalid request data");
	    	
	    	// business Exceptions

	    	
	    	public String message;
	    	public Integer code;
	    	
	    	private Type(Integer code,String message)
	    	{	
	    		this.code=code;
	    		this.message=message;
	    	}
	    	
	    }
	    
	    public Map<String,Object> wrap()
	    {
	    	Map<String,Object> errorRes=new Hashtable<>();
	    	errorRes.put("code", this.errorCode);
	    	errorRes.put("message", this.errorMessage);
	    	if (fields!=null)
	    	{
		    	errorRes.put("field", this.fields);
	    	}
	    	return errorRes;
	    }
}
