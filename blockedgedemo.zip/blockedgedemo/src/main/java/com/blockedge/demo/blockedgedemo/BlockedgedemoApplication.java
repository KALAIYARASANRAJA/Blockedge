package com.blockedge.demo.blockedgedemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BlockedgedemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(BlockedgedemoApplication.class, args);
	}
}
