package com.blockedge.demo.blockedgedemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.blockedge.demo.blockedgedemo.common.exceptions.RestAPIException;
import com.blockedge.demo.blockedgedemo.model.Person;
import com.blockedge.demo.blockedgedemo.service.PersonService;
import com.blockedge.demo.blockedgedemo.common.exceptions.RestAPIException.Type;

@RestController
public class PersonsController {
	
	
	@Autowired
	private PersonService productService;
	
	@GetMapping("api/v1/persons")
	@CrossOrigin
	public List<Person> getPersons(
			@RequestParam(value="name" ,required=false) String name,
			@RequestParam(value="address" ,required=false) String address,
			@RequestParam(value="phone" ,required=false) String phone,
			@RequestParam(value="salary" ,required=false) String salary,
			@RequestParam(value="pension" ,required=false) String pension,
			@RequestParam(value="search" ,required=false) String searchKey) throws Exception
	{
		List<Person> persons=productService.getPersons(name, address, phone, salary, pension, searchKey);		
		 System.out.println(persons.toString()); 
		 if (persons==null ||persons.size()==0) {
			 throw new RestAPIException(Type.RESOURCE_NOT_FOUND_CRITERIA);
		 } 
		 return persons;
		
	}
	
	
	

}
