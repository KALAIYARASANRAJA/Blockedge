package com.blockedge.demo.blockedgedemo.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.blockedge.demo.blockedgedemo.dao.model.PersonDAO;
import com.blockedge.demo.blockedgedemo.model.Person;
import com.blockedge.demo.blockedgedemo.repository.PersonRepository;
import com.blockedge.demo.blockedgedemo.translator.PersonTranslator;

@Component
public class PersonService {
	
	@Autowired
	private PersonRepository personRepository;
	
	public List<Person> getPersons(String name,String address,String phone,String salary,String pension,String searchKey)
	{	
		if (name!=null)
		{
			return PersonTranslator.translateFromDAO(personRepository.findByName(name));
		}
		else if (address!=null)
		{	
			return PersonTranslator.translateFromDAO(personRepository.findByAddressContains(address));
		}
		else if (phone!=null)
		{
			return PersonTranslator.translateFromDAO(personRepository.findByPhone(phone));
		}
		else if (salary!=null)
		{	
			BigDecimal salaryInfo=new BigDecimal(salary).setScale(3);
			System.out.println("salary info to be queried " + salaryInfo);
			return PersonTranslator.translateFromDAO(personRepository.findBySalary(salaryInfo));
		}
		else if (pension!=null)
		{
			BigDecimal pensionInfo=new BigDecimal(pension).setScale(3);
			System.out.println("pension info to be queried " + pensionInfo);
			return PersonTranslator.translateFromDAO(personRepository.findByPension(pensionInfo));
		}
		else
		{	
			return PersonTranslator.translateFromDAO(personRepository.findAll(),searchKey);
		}
	}
	
	public void importPersons(List<Person> persons)
	{	
		List<PersonDAO> personsDAO=new ArrayList<>();
		for (Person person: persons)
		{
			PersonDAO personDAO=PersonTranslator.translateToDAO(person);
			personsDAO.add(personDAO);
		}
		personRepository.saveAll(personsDAO);
	}
}
