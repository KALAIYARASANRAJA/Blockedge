package com.blockedge.demo.blockedgedemo.translator;

import java.util.ArrayList;
import java.util.List;

import com.blockedge.demo.blockedgedemo.dao.model.PersonDAO;
import com.blockedge.demo.blockedgedemo.model.Person;

public class PersonTranslator {
	
	public static Person translateFromDAO(PersonDAO personDAO)
	{
		Person person=new Person(personDAO.getName(), personDAO.getAddress(),personDAO.getPhone(), 
								personDAO.getSalary(), personDAO.getPension(), personDAO.getPayCurrency());
		return person;
	}
	
	public static PersonDAO translateToDAO(Person person)
	{
		PersonDAO personDAO=new PersonDAO(person.getName(), person.getAddress(),person.getPhone(), 
				person.getSalary(), person.getPension(), person.getPayCurrency());
		return personDAO;
	}
	
	public static List<Person> translateFromDAO(List<PersonDAO> personDAOList,String filterBySearchKey)
	{	
		
		System.out.println("From DA0" + personDAOList );
		List<Person> personList=new ArrayList<Person>();
		for (PersonDAO personDAO : personDAOList)
		{	
			if((filterBySearchKey ==null) || (filterBySearchKey!=null && personDAO.toString().contains(filterBySearchKey)))
			{
				Person person=new Person(personDAO.getName(), personDAO.getAddress(),personDAO.getPhone(), 
								personDAO.getSalary(), personDAO.getPension(), personDAO.getPayCurrency());
				personList.add(person);
			}
		}
		return personList;
	}
	
	public static List<Person> translateFromDAO(List<PersonDAO> personDAOList)
	{	
		return translateFromDAO(personDAOList,null);
	}

}
