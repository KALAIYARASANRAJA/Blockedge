package com.blockedge.demo.blockedgedemo.dao.model;

import java.math.BigDecimal;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Data
@Table(name="persons") 
public class PersonDAO {
	

	
	@Id
	@Column(name="NAME" , nullable=false)
	private String name;
	
	@Column(name="ADDRESS" , nullable=false)
	private String address;
	
	@Column(name="PHONE" , nullable=false)
	private String phone;
	
	@Column(name="SALARY" , nullable=false)
	private BigDecimal salary;
	
	@Column(name="PENSION" , nullable=false)
	private BigDecimal pension;
	
	@Column(name="CURRENCY" , nullable=false)
	private String payCurrency;
	
	public PersonDAO()
	{
		
	}
	
	public PersonDAO(String name, String address, String phone, BigDecimal salary,BigDecimal pension, String payCurrency) {
		super();
		this.name = name;
		this.address = address;
		this.phone = phone;
		this.salary = salary;
		this.pension = pension;
		this.payCurrency = payCurrency;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public String getPhone() {
		return phone;
	}

	public BigDecimal getSalary() {
		return salary;
	}

	public BigDecimal getPension() {
		return pension;
	}

	public String getPayCurrency() {
		return payCurrency;
	}
	
	
	public String toString()
	{	
		return getName()+ " "+getAddress()+" "+getPhone()+" "+getSalary()+" "+getPension();
		
	}

}
