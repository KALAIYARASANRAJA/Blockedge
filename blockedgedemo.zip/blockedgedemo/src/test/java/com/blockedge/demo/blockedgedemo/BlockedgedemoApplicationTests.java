package com.blockedge.demo.blockedgedemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BlockedgedemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
